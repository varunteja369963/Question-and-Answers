<?php
include_once('connection.php');
$username = 'babu'
; $key = md5($username)
; $verificationcode = 23514586
; echo "<a href = 'emailconfirm.php?username=$username&key=$key&verificationcode=$verificationcode'  class = 'sabiduria_button' id = 'sabiduria_button'>"
; echo 'Activate my account'
; echo '</a>'
;
mysqli_select_db($conn, 'membersinwebsite');
mysqli_select_db($conn, 'membersinwebsite');
mysqli_select_db($conn, 'membersinwebsite');
mysqli_select_db($conn, 'membersinwebsite');
mysqli_select_db($conn, 'membersinwebsite');

  ?>

