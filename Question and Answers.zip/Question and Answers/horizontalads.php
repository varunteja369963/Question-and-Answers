<?php
session_start();
include_once('connection3.php');
?>
<html>
<head>
    <link href = "horizontalads.css" type = "text/css" rel = "stylesheet"/>
</head>
<body>
    <div class = "total_page">
        <div class = "container">
<div class = "left_for_pic">
<img src = "shopping.png" class = "sabiduria_product_image"/>
</div>
<div class = "right_for_matter">
<span style = "font-style: italic">products from</span>
<span style = "font-size: 20px">sabiduria</span>
 </div>
        </div>
</div>
</body>
</html>

