 dictionary = 
{
    "a": "came a",
    "b": "came b",
    "c": "came c"
}

var k = "b";
for (var i = 1; i <= 5000; i++) {
   dictionary["b"] = "helloworld";
} 