$(document).ready(function() {
  $("body").find(".ads_from_sabiduria_horizontal").load("sabiduriahorizontalads.php");
});