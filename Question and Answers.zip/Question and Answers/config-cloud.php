<?php

\Cloudinary::config(array( 
    "cloud_name" => "sabiduria-in", 
    "api_key" => "133979951381718", 
    "api_secret" => "ac7t8IbagC2tGVX0dqmdqd4_ju0" 
  ));
?>