
<?php
$str = "pawan";
$key = md5($str);

$username = rawurlencode($str);
echo '<a href = "emailconfirm.php?username='.$username.'&key='.$key.'&verificationcode=29322206">';
echo "link";
echo '</a>';
?>
