<?php
session_start();
include_once('connection6.php');
?>
<html>
<head>
    <link href = "horizontalads.css" type = "text/css" rel = "stylesheet"/>
</head>
<body>
    <div class = "total_page">
        <div class = "container">
<div class = "left_for_pic">
    <?php
  echo '<img src = "shopping.png" class = "sabiduria_product_image"/>';
?>
</div>
<div class = "right_for_matter">

    <div class = "product_name">pepe jeans from sabiduria</div>

    <div class = "product_properties">
        <div class = "property_1">size: 32*64</div>
        <div class = "property_2">2 Jeans: 749/-Rs</div>
    </div>

    <div class = product_price_div>
    <span class = "only">Only</span>
    <span class = "product_price">49999/-RS</span>
</div>

    <div class = "get_product_button">
    <button type = "button" class = "get_product">Buy it</button>
</div>

<div class = "from_sabiduria">
<span class = "ads_from">ads from</span>
<span class = "sabiduria">sabiduria</span>
</div>

 </div>
        </div>
</div>
</body>
</html>