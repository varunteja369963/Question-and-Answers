<?php
session_start();
include_once('connection4.php');

function addPoint() {
    global $conn;
    $questionuuid = $_POST['questionuuid'];
    $selectpoint1 = $conn->prepare("SELECT askeduser, points, userpointed FROM `solvemyproblemquestions` WHERE uuid = ?");
    $selectpoint1->bind_param("s", $questionuuid);
    $selectpoint1->execute();
    $resultpoint1 = $selectpoint1->get_result();
    if ($resultpoint1->num_rows != 1) { 
        echo 3;
        die();
      } 
      else { 
    $rowpoint1 = $resultpoint1->fetch_assoc();
    $points1 = (int)$rowpoint1['points'];
    $pointeduser = $rowpoint1['userpointed'];
    $askeduser = $rowpoint1['askeduser'];
    $hashusername = md5($rowpoint1['askeduser']);
      }
    mysqli_free_result($resultpoint1);
    $resultpoint1->close();
    
}
addPoint();
$conn->close();
?>