<?php

namespace Cloudinary\Api;

/**
 * Class NotFound
 * @package Cloudinary\Api
 */
class NotFound extends Error
{
}
